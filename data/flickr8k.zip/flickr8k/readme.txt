place the flickr8k folder into data/ folder
download the raw images from here: http://nlp.cs.illinois.edu/HockenmaierGroup/Framing_Image_Description/KCCA.html
and place them all into flickr8k/imgs . You only have to do this if you wish to visualize the predictions

